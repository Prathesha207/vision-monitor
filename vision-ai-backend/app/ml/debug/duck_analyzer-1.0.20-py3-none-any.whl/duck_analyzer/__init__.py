﻿from .analyzer import DuckAnalyzer
